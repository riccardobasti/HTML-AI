/*
 * UNISEFE VREL CANONICAL
 * ======================
 *
 * Canonical BYTE-native VREL provider recovered from the tested branch:
 *
 *   REL BYTE -> VREL.get(REL_BYTES) -> VALUE
 *
 * Properties of this implementation:
 * - same REL bytes -> same VALUE
 * - VALUE is computed on demand
 * - no persistent W[][] matrix
 * - no PRNG
 * - VREL replaces matrix scalar access only
 * - Transformer/non-matrix arithmetic stays outside VREL
 *
 * Canonical 12-byte REL layout:
 *
 *   byte 0       kind      = 2  (matrix scalar)
 *   byte 1       family
 *   bytes 2..5   row       uint32 little-endian
 *   bytes 6..9   col       uint32 little-endian
 *   bytes 10..11 reserved = 0
 *
 * Canonical tested law:
 *
 *   u = ((3(r+1) + 5(c+1) + ((r XOR c) & 255)) mod 257) / 256
 *   VALUE = (2u - 1) * 0.25
 *
 * IMPORTANT
 * ---------
 * This file preserves the recovered tested law. Do not silently replace the
 * provider with hashes, PRNGs, hidden lookup tables, or stored matrices.
 *
 * VREL does NOT replace softmax, normalization, residuals, activations,
 * causal masking, tokenization, cognitive logic, or any other non-matrix
 * operation.
 *
 * License: use the repository license.
 */

(function (root, factory) {
  "use strict";
  const api = factory();

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.UNISEFE_VREL_CANONICAL = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const VERSION = "1.0.0-canonical";

  const REL_KIND = Object.freeze({
    MATRIX_SCALAR: 2
  });

  const VREL_FAMILY = Object.freeze({
    COGNITIVE_W: 1
  });

  const REL_BYTES = 12;

  function assertUint32(value, name) {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0 || n > 0xFFFFFFFF || Math.floor(n) !== n) {
      throw new TypeError(`${name} must be an unsigned 32-bit integer`);
    }
    return n >>> 0;
  }

  function familyCode(family) {
    if (typeof family === "number") {
      const f = family >>> 0;
      if (f > 255) throw new RangeError("family must fit in one byte");
      return f;
    }

    const code = VREL_FAMILY[family];
    if (code === undefined) {
      throw new Error("Unknown VREL family: " + family);
    }
    return code;
  }

  /**
   * Build the canonical 12-byte matrix-scalar REL.
   *
   * @param {string|number} family
   * @param {number} row uint32
   * @param {number} col uint32
   * @returns {Uint8Array}
   */
  function REL(family, row, col) {
    const f = familyCode(family);
    const r = assertUint32(row, "row");
    const c = assertUint32(col, "col");

    const b = new Uint8Array(REL_BYTES);

    b[0] = REL_KIND.MATRIX_SCALAR;
    b[1] = f;

    b[2] = r & 255;
    b[3] = (r >>> 8) & 255;
    b[4] = (r >>> 16) & 255;
    b[5] = (r >>> 24) & 255;

    b[6] = c & 255;
    b[7] = (c >>> 8) & 255;
    b[8] = (c >>> 16) & 255;
    b[9] = (c >>> 24) & 255;

    b[10] = 0;
    b[11] = 0;

    return b;
  }

  /**
   * Decode a canonical REL.
   *
   * @param {Uint8Array} b
   */
  function readREL(b) {
    if (!(b instanceof Uint8Array) || b.length !== REL_BYTES) {
      throw new TypeError(`REL must be exactly ${REL_BYTES} bytes`);
    }

    return Object.freeze({
      kind: b[0],
      family: b[1],
      row: (
        b[2] |
        (b[3] << 8) |
        (b[4] << 16) |
        (b[5] << 24)
      ) >>> 0,
      col: (
        b[6] |
        (b[7] << 8) |
        (b[8] << 16) |
        (b[9] << 24)
      ) >>> 0,
      reserved0: b[10],
      reserved1: b[11]
    });
  }

  /**
   * Exact canonical numeric law recovered from the tested BYTE-native branch.
   *
   * @param {number} row uint32
   * @param {number} col uint32
   * @returns {number}
   */
  function canonicalValue(row, col) {
    const r = assertUint32(row, "row");
    const c = assertUint32(col, "col");

    const u = (
      (
        3 * (r + 1) +
        5 * (c + 1) +
        ((r ^ c) & 255)
      ) % 257
    ) / 256;

    return (u * 2 - 1) * 0.25;
  }

  const VREL = {
    calls: 0,

    /**
     * REL BYTE -> scalar VALUE.
     *
     * @param {Uint8Array} relBytes
     * @returns {number}
     */
    get(relBytes) {
      this.calls++;

      const q = readREL(relBytes);

      if (q.kind !== REL_KIND.MATRIX_SCALAR) {
        throw new Error("REL is not a matrix-scalar relation");
      }

      if (q.reserved0 !== 0 || q.reserved1 !== 0) {
        throw new Error("Reserved REL bytes must be zero");
      }

      if (q.family === VREL_FAMILY.COGNITIVE_W) {
        return canonicalValue(q.row, q.col);
      }

      throw new Error("Unsupported VREL family: " + q.family);
    },

    reset() {
      this.calls = 0;
    }
  };

  /**
   * Direct canonical matrix-value accessor.
   */
  function weightAt(family, row, col) {
    return VREL.get(REL(family, row, col));
  }

  /*
   * Transformer adapter recovered from the tested branch.
   *
   * VREL itself is not changed. The transformer's
   * (family, layer, row, col) coordinates are folded into the canonical
   * matrix row, then the canonical BYTE-native provider is queried.
   */
  const FAMILY_STRIDE = 1 << 20;
  const LAYER_STRIDE = 1 << 12;

  function transformerVREL(family, layer, row, col) {
    const f = assertUint32(family, "family");
    const l = assertUint32(layer, "layer");
    const r = assertUint32(row, "row");
    const c = assertUint32(col, "col");

    const relationRow =
      f * FAMILY_STRIDE +
      l * LAYER_STRIDE +
      r;

    /*
     * Canonical REL row is uint32. Fail instead of silently wrapping if a
     * future model exceeds the adapter's address space.
     */
    if (!Number.isSafeInteger(relationRow) || relationRow > 0xFFFFFFFF) {
      throw new RangeError("Transformer REL row exceeds uint32 range");
    }

    return weightAt("COGNITIVE_W", relationRow >>> 0, c);
  }

  /**
   * Utility: byte-for-byte REL comparison.
   */
  function sameREL(a, b) {
    if (!(a instanceof Uint8Array) || !(b instanceof Uint8Array)) return false;
    if (a.length !== b.length) return false;

    for (let i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) return false;
    }
    return true;
  }

  /**
   * Minimal deterministic self-test.
   *
   * It verifies:
   * - REL layout round-trip
   * - same REL -> same VALUE
   * - weightAt() == direct provider access
   * - Transformer adapter determinism
   *
   * This is an implementation-integrity test, not a proof that an external
   * matrix/checkpoint is represented. A reference-equivalence test must compare
   * this provider against the intended REFERENCE on the same REL.
   */
  function selfTest() {
    const cases = [
      [0, 0],
      [1, 0],
      [0, 1],
      [17, 29],
      [255, 255],
      [4096, 7],
      [1048576, 31]
    ];

    const failures = [];

    for (const [row, col] of cases) {
      const relA = REL("COGNITIVE_W", row, col);
      const relB = REL("COGNITIVE_W", row, col);
      const q = readREL(relA);

      if (!sameREL(relA, relB)) {
        failures.push({ row, col, error: "REL bytes differ" });
        continue;
      }

      if (q.row !== (row >>> 0) || q.col !== (col >>> 0)) {
        failures.push({ row, col, error: "REL round-trip failed" });
        continue;
      }

      const a = VREL.get(relA);
      const b = VREL.get(relB);
      const c = weightAt("COGNITIVE_W", row, col);

      if (!Object.is(a, b) || !Object.is(a, c)) {
        failures.push({ row, col, error: "VALUE determinism failed", a, b, c });
      }
    }

    const ta = transformerVREL(10, 0, 3, 2);
    const tb = transformerVREL(10, 0, 3, 2);
    if (!Object.is(ta, tb)) {
      failures.push({ error: "Transformer adapter determinism failed", ta, tb });
    }

    return Object.freeze({
      ok: failures.length === 0,
      bit: failures.length === 0 ? 1 : 0,
      deltaMax: failures.length === 0 ? 0 : null,
      relBytes: REL_BYTES,
      cases: cases.length + 1,
      failures
    });
  }

  /**
   * Reference-equivalence helper.
   *
   * reference(row,col) must independently return the intended matrix/reference
   * VALUE. This helper does not let VREL define its own reference.
   */
  function verifyAgainstReference(reference, rows, cols) {
    if (typeof reference !== "function") {
      throw new TypeError("reference must be a function");
    }

    rows = assertUint32(rows, "rows");
    cols = assertUint32(cols, "cols");

    let differences = 0;
    let deltaMax = 0;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const expected = Number(reference(r, c));
        const actual = weightAt("COGNITIVE_W", r, c);
        const delta = Math.abs(actual - expected);

        if (!Object.is(actual, expected)) differences++;
        if (delta > deltaMax) deltaMax = delta;
      }
    }

    return Object.freeze({
      rows,
      cols,
      comparisons: rows * cols,
      differences,
      deltaMax,
      bit: differences === 0 ? 1 : 0
    });
  }

  return Object.freeze({
    VERSION,
    REL_KIND,
    VREL_FAMILY,
    REL_BYTES,
    FAMILY_STRIDE,
    LAYER_STRIDE,
    REL,
    readREL,
    canonicalValue,
    VREL,
    weightAt,
    transformerVREL,
    sameREL,
    selfTest,
    verifyAgainstReference
  });
});
